from django.shortcuts import render
from django.shortcuts import render
from app1.models import Item

# Create your views here.
def index(request):
    return render(request,'index.html')

# def calendar(request):
#     return render(request,'calendar.html')

def calendar(request):
    #all_details = products_item.objects.all
    #return render(request, 'index.html', {'all':all_details})
    if request.method=="POST":
        fromdate=request.POST.get('fromdate')
        todate=request.POST.get('todate')
        searchresult=Item.objects.raw('select Iname, Email, Mobile, Idate from products_products_item where Idate between "'+fromdate+'" and "'+todate+'" ')
        return render(request,'calendar.html',{"data":searchresult})
        #all_details=Item.objects.raw('select "Iname", "Email", "Mobile", "Idate" from products_item where "Idate" between "'+fromdate+'" and "'+todate+'"')
        #return render(request,'index.html',{"item":all_details}) 
    else:
        displaydata=Item.objects.all()
        return render(request,'calendar.html',{"data":displaydata})