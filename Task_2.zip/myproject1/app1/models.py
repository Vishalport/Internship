from sys import maxunicode
from django.contrib import admin
from django.db import models

# Create your models here.

# def filepath(request, filepath):
#     old_filename = filename
#     timeNow = datetime.datetime.now().strftime('%Y%m%d%M%S')
#     filename = "%s%s", (timeNow, old_filename)
#     return os.path.join('uplods/,filename')


class Item(models.Model):
    Iname = models.TextField(max_length=190)
    Email = models.EmailField(max_length=40, null=True)
    Mobile = models.IntegerField(primary_key=True)
    Idate = models.DateField(null=True)
    class Meta:
        db_table='products_products_item'

    #def __str__(self):
        #return self.Iname()
